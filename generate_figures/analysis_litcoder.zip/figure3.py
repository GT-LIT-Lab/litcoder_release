import pandas as pd

df_1 = pd.read_csv("data_figure2/fir_lpp_final_1.csv")
df_2 = pd.read_csv("data_figure2/fir_lpp_final_2.csv")
df_3 = pd.read_csv("data_figure2/fir_lpp_final_3.csv")
df_4 = pd.read_csv("data_figure2/fir_lpp_final_4.csv")
df_5 = pd.read_csv("data_figure2/fir_lpp_final_5.csv")
# combine all the dataframes
df_lpp_fir = pd.concat([df_1, df_2, df_3, df_4, df_5], ignore_index=True)
print(len(df_lpp_fir))
df_lpp_fir = df_lpp_fir.drop_duplicates(
    subset=["model_name", "layer_idx", "subject", "ndelays", "story_idx"]
)
df_lpp_fir = df_lpp_fir.dropna(subset=["a1_mean"])

print(len(df_lpp_fir))
# collapse the dataframe so that we average stories together for each model_name, layer_idx, subject, ndelays
df_lpp_fir_collapsed = df_lpp_fir.groupby(
    ["model_name", "layer_idx", "subject", "ndelays"], as_index=False
).agg({"a1_mean": "mean", "mean_correlation": "mean", "lanA_mean": "mean"})

df_fir_narratives = pd.read_csv("data_figure2/fir_narratives_final_2.csv")
df_fir_lebel = pd.read_csv("data_figure2/fir_lebel_final.csv")


import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd

# ===== CONFIG =====
MAX_SECONDS = 18.0
# Keep the original great colors
PALETTE = {
    "LeBel (TR=2.0s)": "#1F78B4",
    "Little Prince (TR=2.0s)": "#4DD0E1",
    "Narratives (TR=1.5s)": "#60BD68",
}
ALPHA = 0.8

# ===== DATA PREPARATION =====
# [Same data prep as before]
df_lebel = df_fir_lebel.copy()
df_lebel["dataset"] = "LeBel (TR=2.0s)"

df_lpp = df_lpp_fir_collapsed.copy()
df_lpp["dataset"] = "Little Prince (TR=2.0s)"

df_narratives = df_fir_narratives.copy()
df_narratives["dataset"] = "Narratives (TR=1.5s)"

all_data = pd.concat([df_lebel, df_lpp, df_narratives], ignore_index=True)


def convert_ndelays_to_seconds(row):
    if "Narratives" in row["dataset"]:
        return row["ndelays"] * 1.5
    else:
        return row["ndelays"] * 2.0


all_data["seconds"] = all_data.apply(convert_ndelays_to_seconds, axis=1)

rows = []
for (dataset, seconds), group in all_data.groupby(["dataset", "seconds"]):
    vals = pd.to_numeric(group["lanA_mean"], errors="coerce").dropna().values
    n = len(vals)
    if n == 0:
        mean_corr = np.nan
        sem = np.nan
    else:
        mean_corr = float(np.mean(vals))
        sem = float(np.std(vals, ddof=1) / np.sqrt(n)) if n > 1 else 0.0

    rows.append(
        {
            "dataset": dataset,
            "seconds": seconds,
            "mean_corr": mean_corr,
            "sem": sem,
            "n_subjects": n,
        }
    )

plot_data = pd.DataFrame(rows)

# ===== STYLE =====
# Keep your original excellent styling!
sns.set_theme(context="paper", style="ticks")
plt.rcParams.update({"font.size": 14, "axes.labelsize": 16, "legend.fontsize": 14})

# Keep the original figure size
fig, ax = plt.subplots(figsize=(10, 5.5))

# ===== PLOT =====
# Keep the original plot style - it was great!
for ds, grp in plot_data.groupby("dataset"):
    ax.plot(
        grp["seconds"],
        grp["mean_corr"],
        marker="o",
        markersize=6.0,
        linewidth=3.0,
        label=ds,
        color=PALETTE[ds],
        alpha=ALPHA,
        markerfacecolor="white",
        markeredgewidth=1.5,
    )

    # Add the subtle error bands you had
    ax.fill_between(
        grp["seconds"],
        grp["mean_corr"] - grp["sem"],
        grp["mean_corr"] + grp["sem"],
        color=PALETTE[ds],
        alpha=0.2,
    )

# ===== AXES =====
# Remove ax.set_title and use fig.suptitle instead for proper centering
ax.set_xlabel("Temporal Window (seconds)", fontsize=20)
ax.set_ylabel("Predictivity", fontsize=25, fontweight="bold")
ax.set_xticks(np.arange(0, MAX_SECONDS + 4, 3))
ax.set_xlim(0, MAX_SECONDS + 0.2)
ax.tick_params(labelsize=16)

# Keep the clean spines
sns.despine(ax=ax)

# ===== LEGEND =====
# Put legend back outside like the original
leg = ax.legend(
    title="Dataset",
    frameon=False,
    fontsize=16,
    ncol=1,
    bbox_to_anchor=(1.15, 1),
    loc="upper left",
    borderaxespad=0.0,
)
if leg.get_title():
    leg.get_title().set_fontsize(20)

# ===== SAVE =====
fig.tight_layout()
plt.savefig("figure3_temporal.pdf", dpi=300)


df_lpp_downsampling_1 = pd.read_csv("data_figure2/lpp_downsampling_1.csv")
df_lpp_downsampling_2 = pd.read_csv("data_figure2/lpp_downsampling_2.csv")
# combine the two dataframes
df_lpp_downsampling = pd.concat(
    [df_lpp_downsampling_1, df_lpp_downsampling_2], ignore_index=True
)
df_lpp_downsampling = df_lpp_downsampling.dropna(subset=["mean_correlation"])
df_lpp_downsampling_collapsed = (
    df_lpp_downsampling.groupby(
        ["model_name", "layer_idx", "subject", "downsample_method"]
    )
    .agg({"mean_correlation": "mean", "lanA_mean": "mean"})
    .reset_index()
)


df_narratives_downsampling = pd.read_csv("data_figure2/downsampling_narratives.csv")
df_lebel_downsampling = pd.read_csv("data_figure2/lebel_downsampling.csv")

# drop duplicates where downsampling_method and subject are the same
df_narratives_downsampling = df_narratives_downsampling.drop_duplicates(
    subset=["downsample_method", "subject"]
)
df_lebel_downsampling = df_lebel_downsampling.drop_duplicates(
    subset=["downsample_method", "subject"]
)

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from math import sqrt

# ===== CONFIG =====
ALPHA = 0.85

# Map all methods to consistent display names
method_map = {
    "huth_sum": "Sum",
    "sum": "Sum",
    "huth_average": "Average",
    "average": "Average",
    "huth_last": "Last",
    "last": "Last",
    "lanczos": "Lanczos",
}

# Color palette
PALETTE_DOWNSAMPLE = {
    "Sum": "#1F78B4",
    "Average": "#4DD0E1",
    "Last": "#60BD68",
    "Lanczos": "#FFDD57",
}

# Plot order for methods (hue)
HUE_ORDER = ["Lanczos", "Sum", "Average", "Last"]

# ===== Load & prepare =====
# Use the new dataframes directly - no prepare_dataset needed
df_lebel_downsampling["dataset"] = "Lebel"
df_narratives_downsampling["dataset"] = "Narratives"
df_lpp_downsampling_collapsed["dataset"] = "Little Prince"

combined_down = pd.concat(
    [df_lebel_downsampling, df_narratives_downsampling, df_lpp_downsampling_collapsed],
    ignore_index=True,
)
combined_down["method_display"] = combined_down["downsample_method"].map(method_map)

# ===== Determine dataset order by best mean =====
tmp_means = combined_down.groupby(["dataset", "method_display"], as_index=False).agg(
    mean_corr=("lanA_mean", "mean")
)
dataset_order = (
    tmp_means.groupby("dataset")["mean_corr"]
    .max()
    .sort_values(ascending=False)
    .index.tolist()
)
combined_down["dataset"] = pd.Categorical(
    combined_down["dataset"], categories=dataset_order, ordered=True
)

# ===== Aggregate per (dataset, method) across subjects to get mean and SEM =====
# Using your SEM calculation method
rows = []
for (dataset, method), group in combined_down.groupby(["dataset", "method_display"]):
    vals = pd.to_numeric(group["lanA_mean"], errors="coerce").dropna().values
    n = len(vals)
    if n == 0:
        mean_corr = np.nan
        sem = np.nan
    else:
        mean_corr = float(np.mean(vals))
        # SEM uses sample std (ddof=1); if n==1 set sem=0.0
        sem = float(np.std(vals, ddof=1) / np.sqrt(n)) if n > 1 else 0.0

    rows.append(
        {
            "dataset": dataset,
            "method_display": method,
            "mean": mean_corr,
            "sem": sem,
            "n": n,
        }
    )

agg = pd.DataFrame(rows)

# Ensure we have rows for every dataset × method, even if missing (will plot as gaps)
full_index = pd.MultiIndex.from_product(
    [dataset_order, HUE_ORDER], names=["dataset", "method_display"]
)
agg = agg.set_index(["dataset", "method_display"]).reindex(full_index).reset_index()

# ===== Plot =====
sns.set_theme(context="paper", style="ticks")
plt.rcParams.update(
    {
        "font.size": 14,
        "axes.labelsize": 16,
        "legend.fontsize": 14,
        "xtick.labelsize": 14,
        "ytick.labelsize": 14,
    }
)

# CHANGE: Use FIR plot figure size
fig, ax = plt.subplots(figsize=(10, 5.5))

x = np.arange(len(dataset_order))
n_methods = len(HUE_ORDER)
bar_width = 0.18  # tuned to leave small gaps
total_width = n_methods * bar_width
offsets = (np.arange(n_methods) - (n_methods - 1) / 2) * bar_width

# Draw bars with error bars per method
for i, method in enumerate(HUE_ORDER):
    sub = agg[agg["method_display"] == method]
    # Align means/SEMs in order of dataset_order
    means = sub["mean"].to_numpy()
    sems = sub["sem"].to_numpy()
    # X positions for this method
    xi = x + offsets[i]
    # Colors / styling
    color = PALETTE_DOWNSAMPLE[method]
    # Draw bars (allow NaNs to skip plotting)
    bars = ax.bar(
        xi,
        means,
        width=bar_width,
        color=color,
        alpha=ALPHA,
        edgecolor="black",
        linewidth=0.6,
        label=method,
    )
    # Error bars (SEM) — only where both mean and sem are finite
    valid = np.isfinite(means) & np.isfinite(sems)
    ax.errorbar(
        xi[valid],
        means[valid],
        yerr=sems[valid],
        fmt="none",
        ecolor="black",
        elinewidth=1.0,
        capsize=3,
        capthick=1.0,
    )

# Axes & labels
ax.set_xticks(x)
ax.set_xticklabels(dataset_order, rotation=0)
ax.set_ylabel("Mean LanA Correlation")
ax.set_xlabel("")
ax.tick_params(labelsize=14)
sns.despine(ax=ax)

# Legend (matching your original)
handles, labels = ax.get_legend_handles_labels()
# Ensure legend follows HUE_ORDER
order_map = {m: i for i, m in enumerate(HUE_ORDER)}
sorted_pairs = sorted(zip(labels, handles), key=lambda p: order_map.get(p[0], 999))
labels_sorted = [p[0] for p in sorted_pairs]
handles_sorted = [p[1] for p in sorted_pairs]

leg = ax.legend(
    handles_sorted,
    labels_sorted,
    title="Downsampling Method",
    title_fontsize=20,
    fontsize=16,
    loc="upper left",
    bbox_to_anchor=(1.02, 1),
    frameon=False,
)

fig.tight_layout()
plt.savefig("figure3_downsampling.pdf", dpi=300)
