import pandas as pd

df_lebel_language = pd.read_csv("data_figure_1_A/lebel_language_models.csv")
df_lebel_speech = pd.read_csv("data_figure_1_A/lebel_speech.csv")
df_lebel_wordrate = pd.read_csv("data_figure_1_A/lebel_wordrate.csv")
df_lebel_embeddings = pd.read_csv("data_figure_1_A/lebel_embeddings.csv")

df_lebel_hubert = df_lebel_speech[
    df_lebel_speech["model_name"] == "facebook/hubert-base-ls960"
]
# drop duplicates where model_name, layer and subject are the same
df_lebel_hubert = df_lebel_hubert.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)
# chose layer 11
df_lebel_hubert = df_lebel_hubert[df_lebel_hubert["layer_idx"] == 11]


df_lebel_whisper = df_lebel_speech[
    df_lebel_speech["model_name"] == "openai/whisper-tiny"
]

# drop duplicates where model_name, layer and subject are the same
df_lebel_whisper = df_lebel_whisper.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)
# chose layer 11
df_lebel_whisper = df_lebel_whisper[df_lebel_whisper["layer_idx"] == 3]

df_lebel_gpt = df_lebel_language[df_lebel_language["model_name"] == "gpt2-small"]
# drop duplicates where model_name, layer and subject are the same
df_lebel_gpt = df_lebel_gpt.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)

df_lebel_pythia = df_lebel_language[
    df_lebel_language["model_name"] == "EleutherAI/pythia-160m"
]
# drop duplicates where model_name, layer and subject are the same
df_lebel_pythia = df_lebel_pythia.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)
len(df_lebel_pythia)  # 96 runs for pythia-160m 8 * 12


# Average correlation per layer across subjects
layer_means = (
    df_lebel_pythia.groupby("layer_idx")["lanA_mean"]
    .mean()
    .reset_index(name="mean_corr_avg")
)

# Pick the best layer
best_layer = layer_means.loc[layer_means["mean_corr_avg"].idxmax()]
print(best_layer)


layer_mean_gpt = (
    df_lebel_gpt.groupby("layer_idx")["lanA_mean"]
    .mean()
    .reset_index(name="mean_corr_avg")
)

best_layer_gpt = layer_mean_gpt.loc[layer_mean_gpt["mean_corr_avg"].idxmax()]
print(best_layer_gpt)


print(best_layer_gpt)


# best layer for gpt is 6 best layer for pythia is 5
df_lebel_gpt_a1 = df_lebel_gpt[df_lebel_gpt["layer_idx"] == 0]
df_lebel_pythia_a1 = df_lebel_pythia[df_lebel_pythia["layer_idx"] == 0]

df_lebel_gpt = df_lebel_gpt[df_lebel_gpt["layer_idx"] == 6]
df_lebel_pythia = df_lebel_pythia[df_lebel_pythia["layer_idx"] == 5]

# ok now we should have 8 runs for gpt and pythia where we have a single score for each subject
print(len(df_lebel_gpt))  # 8
print(len(df_lebel_pythia))  # 8
df_lebel_word2vec = df_lebel_embeddings[df_lebel_embeddings["model_name"] == "word2vec"]
# drop duplicates where model_name, layer and subject are the same
df_lebel_word2vec = df_lebel_word2vec.drop_duplicates(subset=["model_name", "subject"])

df_lebel_glove = df_lebel_embeddings[df_lebel_embeddings["model_name"] == "glove"]
# drop duplicates where model_name, layer and subject are the same
df_lebel_glove = df_lebel_glove.drop_duplicates(subset=["model_name", "subject"])

# drop duplicates where model_name and subject are the same for df_lebel_wordrate
df_lebel_wordrate = df_lebel_wordrate.drop_duplicates(subset=["model_name", "subject"])


df_narratives_langauge = pd.read_csv("data_figure_1_A/narratives_language_models.csv")
df_narratives_speech = pd.read_csv("data_figure_1_A/narratives_speech.csv")
df_narratives_embeddings = pd.read_csv("data_figure_1_A/narratives_embeddings.csv")
df_narratives_wordrate = pd.read_csv("data_figure_1_A/narratives_wordrate.csv")


df_narratives_gpt = df_narratives_langauge[
    df_narratives_langauge["model_name"] == "gpt2-small"
]
# drop duplicates where model_name, layer and subject are the same
df_narratives_gpt = df_narratives_gpt.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)
# drop rows where the mean_correlation is NaN
# df_narratives_gpt = df_narratives_gpt.dropna(subset=['mean_correlation'])
# print unique subjects in df_narratives_gpt
print(df_narratives_gpt["subject"].unique())

NARRATIVES_EXPECTED_SUBJECTS = [
    "sub-249",
    "sub-255",
    "sub-256",
    "sub-257",
    "sub-258",
    "sub-260",
    "sub-261",
    "sub-262",
    "sub-263",
    "sub-264",
    "sub-265",
    "sub-267",
    "sub-269",
]


# Unique subjects from the dataframe
unique_subjects = set(df_narratives_gpt["subject"].unique())

# Expected subjects
expected_subjects = set(NARRATIVES_EXPECTED_SUBJECTS)

# Check equality
if unique_subjects == expected_subjects:
    print("✅ Subjects match exactly!")
else:
    print("❌ Subjects do not match.")
    print("Missing from dataframe:", expected_subjects - unique_subjects)
    print("Unexpected in dataframe:", unique_subjects - expected_subjects)


df_narratives_gpt = df_narratives_gpt[
    df_narratives_gpt["subject"].isin(NARRATIVES_EXPECTED_SUBJECTS)
]

print(df_narratives_gpt["subject"].unique())


df_narratives_pythia = df_narratives_langauge[
    df_narratives_langauge["model_name"] == "EleutherAI/pythia-160m"
]
# drop duplicates where model_name, layer and subject are the same
df_narratives_pythia = df_narratives_pythia.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)
# drop rows where the mean_correlation is NaN
df_narratives_pythia = df_narratives_pythia.dropna(subset=["mean_correlation"])
print(df_narratives_pythia["subject"].unique())

NARRATIVES_EXPECTED_SUBJECTS = [
    "sub-249",
    "sub-255",
    "sub-256",
    "sub-257",
    "sub-258",
    "sub-260",
    "sub-261",
    "sub-262",
    "sub-263",
    "sub-264",
    "sub-265",
    "sub-267",
    "sub-269",
]


# Unique subjects from the dataframe
unique_subjects = set(df_narratives_pythia["subject"].unique())

# Expected subjects
expected_subjects = set(NARRATIVES_EXPECTED_SUBJECTS)

# Check equality
if unique_subjects == expected_subjects:
    print("✅ Subjects match exactly!")
else:
    print("❌ Subjects do not match.")
    print("Missing from dataframe:", expected_subjects - unique_subjects)
    print("Unexpected in dataframe:", unique_subjects - expected_subjects)


df_narratives_pythia = df_narratives_pythia[
    df_narratives_pythia["subject"].isin(NARRATIVES_EXPECTED_SUBJECTS)
]

print(df_narratives_pythia["subject"].unique())


layer_mean_gpt_narratives = (
    df_narratives_gpt.groupby("layer_idx")["mean_correlation"]
    .mean()
    .reset_index(name="mean_corr_avg")
)

best_layer_gpt_narratives = layer_mean_gpt_narratives.loc[
    layer_mean_gpt_narratives["mean_corr_avg"].idxmax()
]
print(best_layer_gpt_narratives)


layer_mean_pythia_narratives = (
    df_narratives_pythia.groupby("layer_idx")["mean_correlation"]
    .mean()
    .reset_index(name="mean_corr_avg")
)

best_layer_pythia_narratives = layer_mean_pythia_narratives.loc[
    layer_mean_pythia_narratives["mean_corr_avg"].idxmax()
]
print(best_layer_pythia_narratives)


df_narratives_speech = pd.read_csv("data_figure_1_A/narratives_speech.csv")
df_narratives_whisper = df_narratives_speech[
    df_narratives_speech["speech_model_name"] == "openai/whisper-tiny"
]

# drop duplicates where model_name, layer and subject are the same
df_narratives_whisper = df_narratives_whisper.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)

# drop rows where the mean_correlation is NaN
df_narratives_whisper = df_narratives_whisper.dropna(subset=["mean_correlation"])


# get only the subjects that are in the NARRATIVES_EXPECTED_SUBJECTS
df_narratives_whisper = df_narratives_whisper[
    df_narratives_whisper["subject"].isin(NARRATIVES_EXPECTED_SUBJECTS)
]

print(df_narratives_whisper["subject"].unique())


df_narratives_hubert = df_narratives_speech[
    df_narratives_speech["speech_model_name"] == "facebook/hubert-base-ls960"
]
# drop duplicates where model_name, layer and subject are the same
df_narratives_hubert = df_narratives_hubert.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)
# drop rows where the mean_correlation is NaN
df_narratives_hubert = df_narratives_hubert.dropna(subset=["mean_correlation"])


# get only the subjects that are in the NARRATIVES_EXPECTED_SUBJECTS
df_narratives_hubert = df_narratives_hubert[
    df_narratives_hubert["subject"].isin(NARRATIVES_EXPECTED_SUBJECTS)
]

print(df_narratives_hubert["subject"].unique())


df_narratives_embeddings = pd.read_csv("data_figure_1_A/narratives_embeddings.csv")
df_narratives_glove = df_narratives_embeddings[
    df_narratives_embeddings["model_name"] == "glove"
]

# drop duplicates where model_name, layer and subject are the same
df_narratives_glove = df_narratives_glove.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)

# drop rows where the mean_correlation is NaN
df_narratives_glove = df_narratives_glove.dropna(subset=["mean_correlation"])

# get only the subjects that are in the NARRATIVES_EXPECTED_SUBJECTS
df_narratives_glove = df_narratives_glove[
    df_narratives_glove["subject"].isin(NARRATIVES_EXPECTED_SUBJECTS)
]

print(df_narratives_glove["subject"].unique())


df_narratives_word2vec = df_narratives_embeddings[
    df_narratives_embeddings["model_name"] == "word2vec"
]

# drop duplicates where model_name, layer and subject are the same
df_narratives_word2vec = df_narratives_word2vec.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)

# drop rows where the mean_correlation is NaN
df_narratives_word2vec = df_narratives_word2vec.dropna(subset=["mean_correlation"])

# get only the subjects that are in the NARRATIVES_EXPECTED_SUBJECTS
df_narratives_word2vec = df_narratives_word2vec[
    df_narratives_word2vec["subject"].isin(NARRATIVES_EXPECTED_SUBJECTS)
]

df_narratives_wordrate = pd.read_csv("data_figure_1_A/narratives_wordrate.csv")

# drop duplicates where model_name and subject are the same
df_narratives_wordrate = df_narratives_wordrate.drop_duplicates(
    subset=["model_name", "subject"]
)

# drop rows where the mean_correlation is NaN
df_narratives_wordrate = df_narratives_wordrate.dropna(subset=["mean_correlation"])

# get only the subjects that are in the NARRATIVES_EXPECTED_SUBJECTS
df_narratives_wordrate = df_narratives_wordrate[
    df_narratives_wordrate["subject"].isin(NARRATIVES_EXPECTED_SUBJECTS)
]

print(df_narratives_wordrate["subject"].unique())


df_lpp_language_models = pd.read_csv(
    "data_figure_1_A/lpp_language_models_combined_all.csv"
)
# drop duplicates where model_name, layer_idx, subject are the same
df_lpp_language_models = df_lpp_language_models.drop_duplicates(
    subset=["model_name", "layer_idx", "subject", "story_idx"]
)
len(df_lpp_language_models)

df_language_models_gpt = df_lpp_language_models[
    df_lpp_language_models["model_name"] == "gpt2-small"
]
df_language_models_pythia = df_lpp_language_models[
    df_lpp_language_models["model_name"] == "EleutherAI/pythia-160m"
]

agg_cols = ["a1_mean", "mean_correlation", "lanA_mean", "v1_mean"]

# 1) (Optional but robust) collapse within each story first
per_story_gpt = df_language_models_gpt.groupby(
    ["model_name", "layer_idx", "subject", "story_idx"], as_index=False
)[agg_cols].mean()
per_story_pythia = df_language_models_pythia.groupby(
    ["model_name", "layer_idx", "subject", "story_idx"], as_index=False
)[agg_cols].mean()

# 2) Average across stories -> one row per (model_name, layer_idx, subject)
df_lpp_language_models_gpt_collapsed = per_story_gpt.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
)[agg_cols].mean()
df_lpp_language_models_pythia_collapsed = per_story_pythia.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
)[agg_cols].mean()


LPP_EXPECTED_SUBJECTS = [
    "sub-EN068",
    "sub-EN105",
    "sub-EN095",
    "sub-EN058",
    "sub-EN103",
    "sub-EN073",
    "sub-EN065",
    "sub-EN091",
    "sub-EN081",
    "sub-EN077",
    "sub-EN098",
    "sub-EN078",
    "sub-EN086",
    "sub-EN101",
    "sub-EN067",
    "sub-EN115",
    "sub-EN106",
    "sub-EN100",
    "sub-EN076",
    "sub-EN113",
    "sub-EN096",
    "sub-EN057",
    "sub-EN070",
    "sub-EN074",
    "sub-EN072",
    "sub-EN110",
    "sub-EN089",
    "sub-EN082",
    "sub-EN104",
    "sub-EN064",
    "sub-EN109",
    "sub-EN088",
    "sub-EN108",
    "sub-EN063",
    "sub-EN062",
    "sub-EN114",
    "sub-EN079",
    "sub-EN061",
    "sub-EN083",
    "sub-EN087",
    "sub-EN084",
    "sub-EN094",
    "sub-EN092",
    "sub-EN069",
]
# Keep only expected subjects
df_lpp_language_models_gpt_collapsed = df_lpp_language_models_gpt_collapsed[
    df_lpp_language_models_gpt_collapsed["subject"].isin(LPP_EXPECTED_SUBJECTS)
]
df_lpp_language_models_pythia_collapsed = df_lpp_language_models_pythia_collapsed[
    df_lpp_language_models_pythia_collapsed["subject"].isin(LPP_EXPECTED_SUBJECTS)
]

print(len(df_lpp_language_models_gpt_collapsed))
print(len(df_lpp_language_models_pythia_collapsed))


# count number of unique layers and subjects in df_lpp_language_models_gpt_collapsed
print(len(df_lpp_language_models_gpt_collapsed["layer_idx"].unique()))
print(len(df_lpp_language_models_gpt_collapsed["subject"].unique()))

# count number of unique layers and subjects in df_lpp_language_models_pythia_collapsed
print(len(df_lpp_language_models_pythia_collapsed["layer_idx"].unique()))
print(len(df_lpp_language_models_pythia_collapsed["subject"].unique()))


df_lpp_pythia = pd.read_csv("data_figure_1_A/lpp_combined_pythia.csv")
print(len(df_lpp_pythia))

df_lpp_speech = pd.read_csv("data_figure_1_A/lpp_speech_final_2.csv")
print(len(df_lpp_speech))
# drop duplicates where model_name, layer_idx, subject are the same
df_lpp_speech = df_lpp_speech.drop_duplicates(
    subset=["model_name", "layer_idx", "subject", "story_idx"]
)
print(len(df_lpp_speech))

# drop rows where the mean_correlation is NaN
df_lpp_speech = df_lpp_speech.dropna(subset=["mean_correlation"])
print(len(df_lpp_speech))


df_lpp_speech[
    (df_lpp_speech["model_name"] == "facebook/hubert-base-ls960")
    & (df_lpp_speech["subject"] == "sub-EN057")
]

df_lpp_whisper = df_lpp_speech[df_lpp_speech["model_name"] == "openai/whisper-tiny"]
df_lpp_hubert = df_lpp_speech[
    df_lpp_speech["model_name"] == "facebook/hubert-base-ls960"
]
print(len(df_lpp_whisper))
# collapse the dataframes
df_lpp_whisper_collapsed = df_lpp_whisper.groupby(
    ["model_name", "layer_idx", "subject", "story_idx"], as_index=False
).agg(
    {
        "mean_correlation": "mean",
        "lanA_mean": "mean",
        "a1_mean": "mean",
        "v1_mean": "mean",
    }
)
df_lpp_hubert_collapsed = df_lpp_hubert.groupby(
    ["model_name", "layer_idx", "subject", "story_idx"], as_index=False
).agg(
    {
        "mean_correlation": "mean",
        "lanA_mean": "mean",
        "a1_mean": "mean",
        "v1_mean": "mean",
    }
)

print(len(df_lpp_whisper_collapsed))
print(len(df_lpp_hubert_collapsed))

# get only the subjects that are in the LPP_EXPECTED_SUBJECTS
df_lpp_whisper_collapsed = df_lpp_whisper_collapsed[
    df_lpp_whisper_collapsed["subject"].isin(LPP_EXPECTED_SUBJECTS)
]
df_lpp_hubert_collapsed = df_lpp_hubert_collapsed[
    df_lpp_hubert_collapsed["subject"].isin(LPP_EXPECTED_SUBJECTS)
]

print(len(df_lpp_whisper_collapsed["subject"].unique()))
print(len(df_lpp_hubert_collapsed["subject"].unique()))


agg_cols = ["mean_correlation", "lanA_mean", "a1_mean", "v1_mean"]

# 2) Average across stories -> one row per (model_name, layer_idx, subject)
df_lpp_whisper_collapsed = df_lpp_whisper_collapsed.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
)[agg_cols].mean()

df_lpp_hubert_collapsed = df_lpp_hubert_collapsed.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
)[agg_cols].mean()
df_lpp_hubert = df_lpp_speech[
    df_lpp_speech["model_name"] == "facebook/hubert-base-ls960"
]
print(len(df_lpp_hubert))
# drop duplicates where model_name, layer and subject are the same
df_lpp_hubert = df_lpp_hubert.drop_duplicates(
    subset=["model_name", "layer_idx", "subject"]
)

# drop rows where the mean_correlation is NaN
df_lpp_hubert = df_lpp_hubert.dropna(subset=["mean_correlation"])
df_lpp_hubert = df_lpp_hubert[df_lpp_hubert["subject"].isin(LPP_EXPECTED_SUBJECTS)]

print(len(df_lpp_hubert["subject"].unique()))

len(df_lpp_hubert)


df_lpp_wordrate = pd.read_csv("data_figure_1_A/lpp_wordrate.csv")
# drop duplicates where model_name, layer_idx, subject are the same
print(len(df_lpp_wordrate))
df_lpp_wordrate = df_lpp_wordrate.drop_duplicates(
    subset=["model_name", "layer_idx", "subject", "story_idx"]
)
print(len(df_lpp_wordrate))

# drop rows where the mean_correlation is NaN
df_lpp_wordrate = df_lpp_wordrate.dropna(subset=["mean_correlation"])
print(len(df_lpp_wordrate))

# collapse the dataframes
df_lpp_wordrate_collapsed = df_lpp_wordrate.groupby(
    ["model_name", "layer_idx", "subject", "story_idx"], as_index=False
).agg(
    {
        "mean_correlation": "mean",
        "lanA_mean": "mean",
        "a1_mean": "mean",
        "v1_mean": "mean",
    }
)
agg_cols = ["mean_correlation", "lanA_mean", "a1_mean", "v1_mean"]

# collapse across stories → one row per (model_name, layer_idx, subject)
df_lpp_wordrate_collapsed = df_lpp_wordrate_collapsed.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
)[agg_cols].mean()


df_lpp_embeddings = pd.read_csv("data_figure_1_A/lpp_embeddings.csv")
print(len(df_lpp_embeddings))
# drop duplicates where model_name, layer_idx, subject are the same
df_lpp_embeddings = df_lpp_embeddings.drop_duplicates(
    subset=["model_name", "layer_idx", "subject", "story_idx"]
)
print(len(df_lpp_embeddings))
# drop rows where the mean_correlation is NaN
df_lpp_embeddings = df_lpp_embeddings.dropna(subset=["mean_correlation"])
print(len(df_lpp_embeddings))

df_lpp_glove = df_lpp_embeddings[df_lpp_embeddings["model_name"] == "glove"]

df_lpp_glove = df_lpp_glove[df_lpp_glove["subject"].isin(LPP_EXPECTED_SUBJECTS)]
# collapse the dataframes
df_lpp_glove_collapsed = df_lpp_glove.groupby(
    ["model_name", "layer_idx", "subject", "story_idx"], as_index=False
).agg(
    {
        "mean_correlation": "mean",
        "lanA_mean": "mean",
        "a1_mean": "mean",
        "v1_mean": "mean",
    }
)
agg_cols = ["mean_correlation", "lanA_mean", "a1_mean", "v1_mean"]

# collapse across stories → one row per (model_name, layer_idx, subject)
df_lpp_glove_collapsed = df_lpp_glove_collapsed.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
)[agg_cols].mean()


df_lpp_word2vec = df_lpp_embeddings[df_lpp_embeddings["model_name"] == "word2vec"]

# collapse the dataframes
df_lpp_word2vec_collapsed = df_lpp_word2vec.groupby(
    ["model_name", "layer_idx", "subject", "story_idx"], as_index=False
).agg(
    {
        "mean_correlation": "mean",
        "lanA_mean": "mean",
        "a1_mean": "mean",
        "v1_mean": "mean",
    }
)
agg_cols = ["mean_correlation", "lanA_mean", "a1_mean", "v1_mean"]

# collapse across stories → one row per (model_name, layer_idx, subject)
df_lpp_word2vec_collapsed = df_lpp_word2vec_collapsed.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
)[agg_cols].mean()


import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd

# -------------------------
# 1) CONFIG / INPUT DATAFRAMES
# -------------------------
metric_col = "lanA_mean"

DATASETS = {
    "LeBel": {
        "WordRate": df_lebel_wordrate,
        "GloVe": df_lebel_glove,
        "Word2Vec": df_lebel_word2vec,
        "Whisper": df_lebel_whisper,
        "HuBERT": df_lebel_hubert,
        "GPT-2": df_lebel_gpt,
        "Pythia": df_lebel_pythia,
    },
    "Narratives": {
        "WordRate": df_narratives_wordrate,
        "GloVe": df_narratives_glove,
        "Word2Vec": df_narratives_word2vec,
        "Whisper": df_narratives_whisper,
        "HuBERT": df_narratives_hubert,
        "GPT-2": df_narratives_gpt,
        "Pythia": df_narratives_pythia,
    },
    "Little Prince": {
        "WordRate": df_lpp_wordrate_collapsed,
        "GloVe": df_lpp_glove_collapsed,
        "Word2Vec": df_lpp_word2vec_collapsed,
        "Whisper": df_lpp_whisper_collapsed,
        "HuBERT": df_lpp_hubert_collapsed,
        "GPT-2": df_lpp_language_models_gpt_collapsed,
        "Pythia": df_lpp_language_models_pythia_collapsed,
    },
}

# -------------------------
# 2) COLOR SETUP (your requested colors)
# -------------------------
model_groups = {
    "WordRate": {"models": ["WordRate"], "base_color": "#1F78B4"},
    "Embeddings": {"models": ["GloVe", "Word2Vec"], "base_color": "#4DD0E1"},
    "Speech": {"models": ["Whisper", "HuBERT"], "base_color": "#60BD68"},
    "LLMs": {"models": ["GPT-2", "Pythia"], "base_color": "#E377C2"},
}


def two_tints(hex_color):
    """Return two distinct tints from a base hex color (base, a darker variant)."""
    import matplotlib.colors as mcolors

    rgb = np.array(mcolors.to_rgb(hex_color))
    darker = np.clip(rgb * 0.75, 0, 1)  # 25% darker
    return mcolors.to_hex(rgb), mcolors.to_hex(darker)


# Build model->color mapping honoring your base colors
model_colors = {}
for group_name, info in model_groups.items():
    models = info["models"]
    base = info["base_color"]
    if len(models) == 1:
        model_colors[models[0]] = base
    elif len(models) == 2:
        c1, c2 = two_tints(base)
        model_colors[models[0]] = c1
        model_colors[models[1]] = c2
    else:
        # If ever more than 2, generate a small gradient around base
        import colorsys
        import matplotlib.colors as mcolors

        r, g, b = mcolors.to_rgb(base)
        h, s, v = colorsys.rgb_to_hsv(r, g, b)
        vals = np.linspace(0.8, 1.0, len(models))
        for m, vv in zip(models, vals):
            rr, gg, bb = colorsys.hsv_to_rgb(h, s, vv)
            model_colors[m] = mcolors.to_hex((rr, gg, bb))

# -------------------------
# 3) AGGREGATE (mean ± SEM across subjects)
# -------------------------
rows = []
for dataset, model_dict in DATASETS.items():
    for model, df in model_dict.items():
        if df is None:
            continue
        if metric_col not in df.columns:
            raise ValueError(f"{model} @ {dataset} is missing column '{metric_col}'")

        vals = pd.to_numeric(df[metric_col], errors="coerce").dropna().values
        n = len(vals)
        if n == 0:
            mean = np.nan
            sem = np.nan
        else:
            mean = float(np.mean(vals))
            # SEM uses sample std (ddof=1); if n==1 set sem=0.0
            sem = float(np.std(vals, ddof=1) / np.sqrt(n)) if n > 1 else 0.0

        rows.append(
            {
                "dataset": dataset,
                "model": model,
                "mean": mean,
                "sem": sem,
                "n": n,
            }
        )

summary = pd.DataFrame(rows)

# Keep a consistent model order within families
ordered_models = [
    "WordRate",
    "GloVe",
    "Word2Vec",
    "Whisper",
    "HuBERT",
    "GPT-2",
    "Pythia",
]

datasets_order = ["Little Prince", "Narratives", "LeBel"]  # your preferred order
summary["model"] = pd.Categorical(
    summary["model"], categories=ordered_models, ordered=True
)
summary["dataset"] = pd.Categorical(
    summary["dataset"], categories=datasets_order, ordered=True
)
summary = summary.sort_values(["dataset", "model"]).reset_index(drop=True)

# -------------------------
# 4) PLOT (grouped by dataset, bars per model, with SEM error bars)
# -------------------------
plt.style.use("default")
sns.set_style("white")
plt.rcParams["font.family"] = "Arial"


bar_width = 0.25
model_gap = 0.00
dataset_gap = 0.8

fig, ax = plt.subplots(figsize=(14, 8))

# Compute x positions for each dataset group
dataset_positions = {}
current_x = 0.0
for ds in datasets_order:
    ds_df = summary[summary["dataset"] == ds]
    # Ensure all models exist; if some are missing, still reserve positions for ordering
    x_positions = []
    for m in ordered_models:
        x_positions.append(current_x)
        current_x += bar_width + model_gap
    dataset_positions[ds] = x_positions
    current_x += dataset_gap - model_gap  # after last bar, add dataset gap

# Draw bars with error bars
for ds in datasets_order:
    ds_df = summary[summary["dataset"] == ds]
    x_positions = dataset_positions[ds]

    for i, m in enumerate(ordered_models):
        row = ds_df[ds_df["model"] == m]
        if row.empty:
            continue
        mean = row["mean"].values[0]
        sem = row["sem"].values[0]
        color = model_colors.get(m, "#999999")

        ax.bar(
            x_positions[i],
            mean,
            bar_width,
            color=color,
            alpha=0.8,
            edgecolor="None",
            linewidth=1.2,
            yerr=sem,
            capsize=0,
            ecolor="black",
            error_kw=dict(linewidth=1),
        )

# Dataset center ticks
dataset_centers = [np.mean(dataset_positions[ds]) for ds in datasets_order]
ax.set_xticks(dataset_centers)

ax.set_xticklabels(datasets_order, fontsize=25, ha="center", fontweight="bold")

# Vertical separators between datasets
for idx, ds in enumerate(datasets_order):
    if idx == 0:
        continue
    left_first_bar = dataset_positions[ds][0]
    sep_x = left_first_bar - (dataset_gap * 0.5)
    # ax.axvline(x=sep_x, color='gray', linestyle='--', alpha=0.5, linewidth=1.5)

# Legend (models with your colors)
legend_handles = [
    plt.Rectangle((0, 0), 1, 1, facecolor=model_colors[m], alpha=0.8, label=m)
    for m in ordered_models
    if m in model_colors
]
leg = ax.legend(
    handles=legend_handles,
    loc="upper left",
    fontsize=20,
    frameon=False,
    fancybox=False,
    shadow=False,
)
leg.get_frame().set_facecolor("white")
leg.get_frame().set_alpha(0.9)

# Labels/limits
ax.set_ylabel("Predictivity", fontsize=24, fontweight="bold")
ax.set_title(
    "Model Performance Across Datasets", fontsize=24, fontweight="bold", pad=20
)

# y-limit with small headroom
max_mean = np.nanmax(summary["mean"].values) if len(summary) else 1.0

# x-limits to frame last group nicely
all_positions = np.concatenate(list(dataset_positions.values()))
ax.set_xlim(all_positions.min() - 0.3, all_positions.max() + bar_width + 0.3)

# Clean styling
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.spines["left"].set_linewidth(1.5)
ax.spines["bottom"].set_linewidth(1.5)
ax.spines["bottom"].set_position(("outward", 10))
ax.spines["bottom"].set_bounds((dataset_centers[0], dataset_centers[-1]))
ax.spines["left"].set_bounds((0, 0.25))
ax.spines["left"].set_position(("outward", 5))


# ax.grid(axis='y', alpha=0.3, linestyle='-', linewidth=0.5)
ax.tick_params(axis="y", labelsize=25)
ax.tick_params(axis="x", which="both", length=6, width=1.5, bottom=True, top=False)
ax.tick_params(axis="y", which="both", length=6, width=1.5, left=True, right=False)

yticks = np.arange(0, 0.255, 0.05)  # 0, 0.1, ..., 1.0

ax.set_yticks(yticks)
ax.set_yticklabels([f"{y:.2f}" for y in yticks], fontsize=14)

max_mean = np.nanmax(summary["mean"].values) if len(summary) else 1.0
ax.set_ylim(0, 0.25)
ax.axhline(y=0.0, color="grey", linestyle="--", alpha=0.5, linewidth=1.5)
ax.set_xticklabels(datasets_order, ha="center")
ax.tick_params(axis="x", labelsize=24)
ax.tick_params(axis="y", labelsize=20)
plt.tight_layout()
# plt.subplots_adjust(bottom=0.15)
plt.savefig("figure1.pdf", format="pdf", bbox_inches="tight")

# Optional: print Ns to sanity-check subject counts per (dataset, model)
print(
    summary.pivot(index="dataset", columns="model", values="n").reindex(
        index=datasets_order, columns=ordered_models
    )
)

print("\nSEM values:")
print(
    summary.pivot(index="dataset", columns="model", values="sem").reindex(
        index=datasets_order, columns=ordered_models
    )
)


import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd

# -------------------------
# 1) CONFIG / INPUT DATAFRAMES (Lebel only)
# -------------------------
# Define dataframes for each model and region combination
# If a region uses the same df as another, just reference the same df
MODEL_REGION_DATA = {
    "WordRate": {
        "V1": {"df": df_lebel_wordrate, "column": "v1_mean"},
        "A1": {"df": df_lebel_wordrate, "column": "a1_mean"},  # Different df for A1!
        "LanA": {"df": df_lebel_wordrate, "column": "lanA_mean"},
    },
    "GloVe": {
        "V1": {"df": df_lebel_glove, "column": "v1_mean"},
        "A1": {"df": df_lebel_glove, "column": "a1_mean"},  # Different df for A1!
        "LanA": {"df": df_lebel_glove, "column": "lanA_mean"},
    },
    "Word2Vec": {
        "V1": {"df": df_lebel_word2vec, "column": "v1_mean"},
        "A1": {"df": df_lebel_word2vec, "column": "a1_mean"},  # Different df for A1!
        "LanA": {"df": df_lebel_word2vec, "column": "lanA_mean"},
    },
    "Whisper": {
        "V1": {"df": df_lebel_whisper, "column": "v1_mean"},
        "A1": {"df": df_lebel_whisper, "column": "a1_mean"},  # Different df for A1!
        "LanA": {"df": df_lebel_whisper, "column": "lanA_mean"},
    },
    "HuBERT": {
        "V1": {"df": df_lebel_hubert, "column": "v1_mean"},
        "A1": {"df": df_lebel_hubert, "column": "a1_mean"},  # Different df for A1!
        "LanA": {"df": df_lebel_hubert, "column": "lanA_mean"},
    },
    "GPT-2": {
        "V1": {"df": df_lebel_gpt, "column": "v1_mean"},
        "A1": {"df": df_lebel_gpt, "column": "a1_mean"},  # Different df for A1!
        "LanA": {"df": df_lebel_gpt, "column": "lanA_mean"},
    },
    "Pythia": {
        "V1": {"df": df_lebel_pythia, "column": "v1_mean"},
        "A1": {"df": df_lebel_pythia, "column": "a1_mean"},  # Different df for A1!
        "LanA": {"df": df_lebel_pythia, "column": "lanA_mean"},
    },
}

# Brain regions to plot
BRAIN_REGIONS = ["V1", "A1", "LanA"]

# -------------------------
# 2) COLOR SETUP (exact same as first plot)
# -------------------------
model_groups = {
    "WordRate": {"models": ["WordRate"], "base_color": "#1F78B4"},
    "Embeddings": {"models": ["GloVe", "Word2Vec"], "base_color": "#4DD0E1"},
    "Speech": {"models": ["Whisper", "HuBERT"], "base_color": "#60BD68"},
    "LLMs": {"models": ["GPT-2", "Pythia"], "base_color": "#E377C2"},
}


def two_tints(hex_color):
    """Return two distinct tints from a base hex color (base, a darker variant)."""
    import matplotlib.colors as mcolors

    rgb = np.array(mcolors.to_rgb(hex_color))
    darker = np.clip(rgb * 0.75, 0, 1)  # 25% darker
    return mcolors.to_hex(rgb), mcolors.to_hex(darker)


# Build model->color mapping honoring your base colors
model_colors = {}
for group_name, info in model_groups.items():
    models = info["models"]
    base = info["base_color"]
    if len(models) == 1:
        model_colors[models[0]] = base
    elif len(models) == 2:
        c1, c2 = two_tints(base)
        model_colors[models[0]] = c1
        model_colors[models[1]] = c2
    else:
        # If ever more than 2, generate a small gradient around base
        import colorsys
        import matplotlib.colors as mcolors

        r, g, b = mcolors.to_rgb(base)
        h, s, v = colorsys.rgb_to_hsv(r, g, b)
        vals = np.linspace(0.8, 1.0, len(models))
        for m, vv in zip(models, vals):
            rr, gg, bb = colorsys.hsv_to_rgb(h, s, vv)
            model_colors[m] = mcolors.to_hex((rr, gg, bb))

# -------------------------
# 3) AGGREGATE (mean ± SEM across subjects for each brain region and model)
# -------------------------
rows = []
for region in BRAIN_REGIONS:
    for model in MODEL_REGION_DATA.keys():
        region_data = MODEL_REGION_DATA[model][region]
        df = region_data["df"]
        column = region_data["column"]

        if df is None:
            continue
        if column not in df.columns:
            raise ValueError(
                f"{model} is missing column '{column}' for region {region}"
            )

        vals = pd.to_numeric(df[column], errors="coerce").dropna().values
        n = len(vals)
        if n == 0:
            mean = np.nan
            sem = np.nan
        else:
            mean = float(np.mean(vals))
            # SEM uses sample std (ddof=1); if n==1 set sem=0.0
            sem = float(np.std(vals, ddof=1) / np.sqrt(n)) if n > 1 else 0.0

        rows.append(
            {
                "region": region,
                "model": model,
                "mean": mean,
                "sem": sem,
                "n": n,
            }
        )

summary = pd.DataFrame(rows)

# Keep a consistent model order within families
ordered_models = [
    "WordRate",
    "GloVe",
    "Word2Vec",
    "Whisper",
    "HuBERT",
    "GPT-2",
    "Pythia",
]

regions_order = ["V1", "A1", "LanA"]  # brain regions order
summary["model"] = pd.Categorical(
    summary["model"], categories=ordered_models, ordered=True
)
summary["region"] = pd.Categorical(
    summary["region"], categories=regions_order, ordered=True
)
summary = summary.sort_values(["region", "model"]).reset_index(drop=True)

# -------------------------
# 4) PLOT (grouped by brain region, bars per model, with SEM error bars)
# -------------------------
plt.style.use("default")
sns.set_style("white")
plt.rcParams["font.family"] = "Arial"

bar_width = 0.25
model_gap = 0.00
region_gap = 0.8

fig, ax = plt.subplots(figsize=(14, 8))

# Compute x positions for each brain region group
region_positions = {}
current_x = 0.0
for region in regions_order:
    region_df = summary[summary["region"] == region]
    # Ensure all models exist; if some are missing, still reserve positions for ordering
    x_positions = []
    for m in ordered_models:
        x_positions.append(current_x)
        current_x += bar_width + model_gap
    region_positions[region] = x_positions
    current_x += region_gap - model_gap  # after last bar, add region gap

# Draw bars with error bars
for region in regions_order:
    region_df = summary[summary["region"] == region]
    x_positions = region_positions[region]

    for i, m in enumerate(ordered_models):
        row = region_df[region_df["model"] == m]
        if row.empty:
            continue
        mean = row["mean"].values[0]
        sem = row["sem"].values[0]
        color = model_colors.get(m, "#999999")

        ax.bar(
            x_positions[i],
            mean,
            bar_width,
            color=color,
            alpha=0.8,
            edgecolor="None",
            linewidth=1.2,
            yerr=sem,
            capsize=0,
            ecolor="black",
            error_kw=dict(linewidth=1),
        )

# Brain region center ticks
region_centers = [np.mean(region_positions[region]) for region in regions_order]
ax.set_xticks(region_centers)
ax.set_xticklabels(regions_order, fontsize=40, ha="center", fontweight="bold")

# Legend (models with your colors)
legend_handles = [
    plt.Rectangle((0, 0), 1, 1, facecolor=model_colors[m], alpha=0.8, label=m)
    for m in ordered_models
    if m in model_colors
]
leg = ax.legend(
    handles=legend_handles,
    loc="upper left",
    fontsize=20,
    frameon=False,
    fancybox=False,
    shadow=False,
)
leg.get_frame().set_facecolor("white")
leg.get_frame().set_alpha(0.9)

# Labels/limits
ax.set_ylabel("Predictivity", fontsize=24, fontweight="bold")
ax.set_title(
    "Model Performance Across Brain Regions (LeBel Dataset)",
    fontsize=24,
    fontweight="bold",
    pad=20,
)

# y-limit with small headroom
max_mean = np.nanmax(summary["mean"].values) if len(summary) else 1.0

# x-limits to frame last group nicely
all_positions = np.concatenate(list(region_positions.values()))
ax.set_xlim(all_positions.min() - 0.3, all_positions.max() + bar_width + 0.3)

# Clean styling
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.spines["left"].set_linewidth(1.5)
ax.spines["bottom"].set_linewidth(1.5)
ax.spines["bottom"].set_position(("outward", 10))
ax.spines["bottom"].set_bounds((region_centers[0], region_centers[-1]))
ax.spines["left"].set_bounds((0, 0.45))
ax.spines["left"].set_position(("outward", 5))

ax.tick_params(axis="y", labelsize=2)
ax.tick_params(axis="x", which="both", length=6, width=1.5, bottom=True, top=False)
ax.tick_params(axis="y", which="both", length=6, width=1.5, left=True, right=False)

yticks = np.arange(0, 0.455, 0.05)  # 0, 0.05, 0.1, ..., 0.25
ax.set_yticks(yticks)
ax.set_yticklabels([f"{y:.2f}" for y in yticks], fontsize=20)

max_mean = np.nanmax(summary["mean"].values) if len(summary) else 1.0
ax.set_ylim(0, 0.45)
ax.axhline(y=0.0, color="grey", linestyle="--", alpha=0.5, linewidth=1.5)
ax.set_xticklabels(regions_order, ha="center")
ax.tick_params(axis="x", labelsize=24)
plt.tight_layout()
plt.savefig("figure1_across_brain_regions.pdf", format="pdf", bbox_inches="tight")

print(
    summary.pivot(index="region", columns="model", values="n").reindex(
        index=regions_order, columns=ordered_models
    )
)
