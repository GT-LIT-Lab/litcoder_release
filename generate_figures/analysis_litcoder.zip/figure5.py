import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats, optimize

df = pd.read_csv("data_figure5/fd_agg.csv")
data_narratives = pd.read_csv("data_figure5/headmotionplot_narratives.csv")
# make df narratives all rows where dataset is narratives

df_narratives_head = df[df["dataset"] == "Narratives"]
df_lebel_head = df[df["dataset"] == "Lebel"]

# count number of unique subjects in data_narratives

data_narratives = data_narratives.drop_duplicates(
    subset=["subject", "layer_idx"], keep="first"
)
subject_layer_means = (
    data_narratives.groupby(["subject", "layer_idx"])["lanA_mean"].mean().reset_index()
)

layer_means = (
    subject_layer_means.groupby("layer_idx")["lanA_mean"]
    .mean()
    .reset_index()
    .sort_values("lanA_mean", ascending=False)
)

print(layer_means)

best_layer = layer_means.iloc[0]
print(
    "Best layer:", best_layer.layer_idx, "with mean correlation", best_layer.lanA_mean
)

# Fix subject IDs to same format (strip "sub-")
data_narratives["sid"] = data_narratives["subject"].str.replace("sub-", "", regex=False)
df_narratives_head["sid"] = df_narratives_head["subject"].astype(str)

# Pick best layer (7)
perf_l7 = (
    data_narratives[data_narratives["layer_idx"] == 7]
    .groupby("sid")["lanA_mean"]
    .mean()
    .reset_index(name="lanA_mean_avg")
)

# Merge with motion
merged = perf_l7.merge(df_narratives_head[["sid", "fd"]], on="sid", how="inner")


# ---- SETTINGS ----
X_COL = "fd"
Y_COL = "lanA_mean_avg"
XLABEL = "Mean FD"
YLABEL = "Predictivity"
EXPORT_PATH = "fd_vs_performance.pdf"

SHOW_LINEAR = False  # optional dashed linear reference
SHOW_POWERLAW = True  # show power-law fit + CI
SHOW_PEARSON = False  # also report Pearson r (off by default)

# Bootstrap
N_BOOT = 200
CI = (2.5, 97.5)

# --- Style ---
PRIMARY = "#1F78B4"
SCATTER_ALPHA = 0.85
LINE_WIDTH = 3.2
CI_ALPHA = 0.18

sns.set_style("white")
plt.rcParams["font.family"] = "Arial"


# ===== Helpers =====
def powerlaw(x, a, b, c):
    return a * np.power(x, b) + c


def fit_powerlaw(x, y):
    # Guard against non-finite data
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mxx = np.nanmax(x)
    a0 = (np.nanmax(y) - np.nanmin(y)) / (np.sqrt(mxx + 1e-8) + 1e-8)
    p0 = [a0, -1.0, np.nanmin(y)]
    bounds = ([-np.inf, -5, -np.inf], [np.inf, 5, np.inf])
    popt, _ = optimize.curve_fit(powerlaw, x, y, p0=p0, bounds=bounds, maxfev=20000)
    return popt  # a, b, c


def bootstrap_powerlaw_curve(
    df, x_col, y_col, x_grid, n_boot=1000, ci=(2.5, 97.5), random_state=0
):
    rng = np.random.default_rng(random_state)
    preds = []
    n = len(df)
    for _ in range(n_boot):
        sample = df.sample(n=n, replace=True, random_state=rng.integers(1, 10**9))
        x_b = sample[x_col].to_numpy()
        y_b = sample[y_col].to_numpy()
        if np.any(~np.isfinite(x_b)) or np.any(~np.isfinite(y_b)):
            continue
        try:
            a, b, c = fit_powerlaw(x_b, y_b)
            preds.append(powerlaw(x_grid, a, b, c))
        except Exception:
            continue
    preds = np.array(preds)
    lower = np.nanpercentile(preds, ci[0], axis=0)
    upper = np.nanpercentile(preds, ci[1], axis=0)
    median = np.nanpercentile(preds, 50, axis=0)
    return median, lower, upper


def bootstrap_b_params(df, x_col, y_col, n_boot=1000, ci=(2.5, 97.5), random_state=0):
    rng = np.random.default_rng(random_state)
    bs = []
    n = len(df)
    for _ in range(n_boot):
        sample = df.sample(n=n, replace=True, random_state=rng.integers(1, 10**9))
        x_b = sample[x_col].to_numpy()
        y_b = sample[y_col].to_numpy()
        if np.any(~np.isfinite(x_b)) or np.any(~np.isfinite(y_b)):
            continue
        try:
            _, b, _ = fit_powerlaw(x_b, y_b)
            bs.append(b)
        except Exception:
            continue
    bs = np.array(bs, dtype=float)
    b_med = float(np.nanmedian(bs))
    b_lo, b_hi = [float(v) for v in np.nanpercentile(bs, ci)]
    return b_med, b_lo, b_hi


def r2_powerlaw(x, y, params):
    y_pred = powerlaw(x, *params)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    return 1.0 - ss_res / ss_tot


# ===== Data =====
# 'merged' must be a DataFrame with columns X_COL and Y_COL
df = merged[[X_COL, Y_COL]].dropna().copy()
x = df[X_COL].to_numpy()
y = df[Y_COL].to_numpy()

# Handle edge case: constant vectors break correlations
const_x = np.allclose(np.nanstd(x), 0.0)
const_y = np.allclose(np.nanstd(y), 0.0)

# ===== Plot =====
fig, ax = plt.subplots(figsize=(9.5, 7.2))

# scatter
ax.scatter(x, y, s=95, alpha=SCATTER_ALPHA, edgecolor="none", color=PRIMARY)

# optional linear trend (light)
if SHOW_LINEAR and not const_x and not const_y:
    m, b_lin = np.polyfit(x, y, 1)
    x_lin = np.linspace(x.min(), x.max(), 100)
    ax.plot(
        x_lin,
        m * x_lin + b_lin,
        linestyle="--",
        linewidth=2.0,
        alpha=0.45,
        color="black",
    )

# power-law fit + bootstrap CI + metrics
if SHOW_POWERLAW:
    # fit
    a_hat, b_hat, c_hat = fit_powerlaw(x, y)

    # curve + CI
    x_grid = np.linspace(x.min(), x.max(), 300)
    median, lower, upper = bootstrap_powerlaw_curve(
        df, X_COL, Y_COL, x_grid, n_boot=N_BOOT, ci=CI, random_state=42
    )
    ax.fill_between(x_grid, lower, upper, alpha=CI_ALPHA, color=PRIMARY, linewidth=0)
    ax.plot(x_grid, median, color=PRIMARY, linewidth=LINE_WIDTH)

    # R^2 for the fitted model
    r2 = r2_powerlaw(x, y, (a_hat, b_hat, c_hat))

    # bootstrap b CI
    b_med, b_lo, b_hi = bootstrap_b_params(
        df, X_COL, Y_COL, n_boot=N_BOOT, ci=CI, random_state=123
    )

    # correlations
    rho_text = ""
    if not const_x and not const_y:
        rho, p_rho = stats.spearmanr(x, y)
        rho_text = rf"\n$\rho$ = {rho:0.2f}"
        if SHOW_PEARSON:
            pr, pp = stats.pearsonr(x, y)
            rho_text += rf"  (Pearson $r$ = {pr:0.2f})"

    # annotation text (large, readable)
    metrics_text = r"$R^2$ = " + f"{r2:0.2f}\n" r"$\rho$ = " + f"{rho:0.2f}\n"

    # annotate (top-right inside axes)
    ax.text(
        0.98,
        0.98,
        metrics_text,
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=30,
        fontweight="bold",
    )

# labels
ax.set_xlabel(XLABEL, fontsize=20, fontweight="bold", labelpad=8)
ax.set_ylabel(YLABEL, fontsize=20, fontweight="bold", labelpad=8)

sns.despine()

# ticks and spines
ax.tick_params(axis="x", labelsize=18, width=1.8, length=7)
ax.tick_params(axis="y", labelsize=18, width=1.8, length=7)
for spine in ["left", "bottom"]:
    ax.spines[spine].set_linewidth(1.8)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

fig.tight_layout()
plt.savefig("figure5_narratives.pdf", dpi=300, bbox_inches="tight")


df_lebel = pd.read_csv("data_figure5/headmotion_lebel.csv")

df_lebel = df_lebel.drop_duplicates(subset=["subject", "layer_idx"], keep="first")
# Step 1: average per subject × layer
subject_layer_means = (
    df_lebel.groupby(["subject", "layer_idx"])["lanA_mean"].mean().reset_index()
)

# Step 2: now average across subjects
layer_means = (
    subject_layer_means.groupby("layer_idx")["lanA_mean"]
    .mean()
    .reset_index()
    .sort_values("lanA_mean", ascending=False)
)

print(layer_means)

best_layer = layer_means.iloc[0]
print(
    "Best layer:", best_layer.layer_idx, "with mean correlation", best_layer.lanA_mean
)

perf_l6 = (
    df_lebel[df_lebel["layer_idx"] == 6]
    .groupby("subject")["lanA_mean"]
    .mean()
    .reset_index(name="lanA_mean_avg")
)

merged = perf_l6.merge(df_lebel_head[["subject", "fd"]], on="subject", how="inner")

# ===== Publication-ready FD vs performance plot (R^2, Spearman's rho, and b CI) =====
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats, optimize

# ---- SETTINGS ----
X_COL = "fd"
Y_COL = "lanA_mean_avg"
XLABEL = "Mean FD"
YLABEL = "Predictivity"
EXPORT_PATH = "fd_vs_performance.pdf"

SHOW_LINEAR = False  # optional dashed linear reference
SHOW_POWERLAW = True  # show power-law fit + CI
SHOW_PEARSON = False  # also report Pearson r (off by default)

# Bootstrap
N_BOOT = 200
CI = (2.5, 97.5)

# --- Style ---
PRIMARY = "#1F78B4"
SCATTER_ALPHA = 0.85
LINE_WIDTH = 3.2
CI_ALPHA = 0.18

sns.set_style("white")
plt.rcParams["font.family"] = "Arial"


# ===== Helpers =====
def powerlaw(x, a, b, c):
    return a * np.power(x, b) + c


def fit_powerlaw(x, y):
    # Guard against non-finite data
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mxx = np.nanmax(x)
    a0 = (np.nanmax(y) - np.nanmin(y)) / (np.sqrt(mxx + 1e-8) + 1e-8)
    p0 = [a0, -1.0, np.nanmin(y)]
    bounds = ([-np.inf, -5, -np.inf], [np.inf, 5, np.inf])
    popt, _ = optimize.curve_fit(powerlaw, x, y, p0=p0, bounds=bounds, maxfev=20000)
    return popt  # a, b, c


def bootstrap_powerlaw_curve(
    df, x_col, y_col, x_grid, n_boot=1000, ci=(2.5, 97.5), random_state=0
):
    rng = np.random.default_rng(random_state)
    preds = []
    n = len(df)
    for _ in range(n_boot):
        sample = df.sample(n=n, replace=True, random_state=rng.integers(1, 10**9))
        x_b = sample[x_col].to_numpy()
        y_b = sample[y_col].to_numpy()
        if np.any(~np.isfinite(x_b)) or np.any(~np.isfinite(y_b)):
            continue
        try:
            a, b, c = fit_powerlaw(x_b, y_b)
            preds.append(powerlaw(x_grid, a, b, c))
        except Exception:
            continue
    preds = np.array(preds)
    lower = np.nanpercentile(preds, ci[0], axis=0)
    upper = np.nanpercentile(preds, ci[1], axis=0)
    median = np.nanpercentile(preds, 50, axis=0)
    return median, lower, upper


def bootstrap_b_params(df, x_col, y_col, n_boot=1000, ci=(2.5, 97.5), random_state=0):
    rng = np.random.default_rng(random_state)
    bs = []
    n = len(df)
    for _ in range(n_boot):
        sample = df.sample(n=n, replace=True, random_state=rng.integers(1, 10**9))
        x_b = sample[x_col].to_numpy()
        y_b = sample[y_col].to_numpy()
        if np.any(~np.isfinite(x_b)) or np.any(~np.isfinite(y_b)):
            continue
        try:
            _, b, _ = fit_powerlaw(x_b, y_b)
            bs.append(b)
        except Exception:
            continue
    bs = np.array(bs, dtype=float)
    b_med = float(np.nanmedian(bs))
    b_lo, b_hi = [float(v) for v in np.nanpercentile(bs, ci)]
    return b_med, b_lo, b_hi


def r2_powerlaw(x, y, params):
    y_pred = powerlaw(x, *params)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    return 1.0 - ss_res / ss_tot


# ===== Data =====
# 'merged' must be a DataFrame with columns X_COL and Y_COL
df = merged[[X_COL, Y_COL]].dropna().copy()
x = df[X_COL].to_numpy()
y = df[Y_COL].to_numpy()

# Handle edge case: constant vectors break correlations
const_x = np.allclose(np.nanstd(x), 0.0)
const_y = np.allclose(np.nanstd(y), 0.0)

# ===== Plot =====
fig, ax = plt.subplots(figsize=(9.5, 7.2))

# scatter
ax.scatter(x, y, s=95, alpha=SCATTER_ALPHA, edgecolor="none", color=PRIMARY)

# optional linear trend (light)
if SHOW_LINEAR and not const_x and not const_y:
    m, b_lin = np.polyfit(x, y, 1)
    x_lin = np.linspace(x.min(), x.max(), 100)
    ax.plot(
        x_lin,
        m * x_lin + b_lin,
        linestyle="--",
        linewidth=2.0,
        alpha=0.45,
        color="black",
    )

# power-law fit + bootstrap CI + metrics
if SHOW_POWERLAW:
    # fit
    a_hat, b_hat, c_hat = fit_powerlaw(x, y)

    # curve + CI
    x_grid = np.linspace(x.min(), x.max(), 300)
    median, lower, upper = bootstrap_powerlaw_curve(
        df, X_COL, Y_COL, x_grid, n_boot=N_BOOT, ci=CI, random_state=42
    )
    ax.fill_between(x_grid, lower, upper, alpha=CI_ALPHA, color=PRIMARY, linewidth=0)
    ax.plot(x_grid, median, color=PRIMARY, linewidth=LINE_WIDTH)

    # R^2 for the fitted model
    r2 = r2_powerlaw(x, y, (a_hat, b_hat, c_hat))

    # bootstrap b CI
    b_med, b_lo, b_hi = bootstrap_b_params(
        df, X_COL, Y_COL, n_boot=N_BOOT, ci=CI, random_state=123
    )

    # correlations
    rho_text = ""
    if not const_x and not const_y:
        rho, p_rho = stats.spearmanr(x, y)
        rho_text = rf"\n$\rho$ = {rho:0.2f}"
        if SHOW_PEARSON:
            pr, pp = stats.pearsonr(x, y)
            rho_text += rf"  (Pearson $r$ = {pr:0.2f})"

    # annotation text (large, readable)
    metrics_text = r"$R^2$ = " + f"{r2:0.2f}\n" r"$\rho$ = " + f"{rho:0.2f}\n"

    # annotate (top-right inside axes)
    ax.text(
        0.98,
        0.98,
        metrics_text,
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=30,
        fontweight="bold",
    )

# labels
ax.set_xlabel(XLABEL, fontsize=20, fontweight="bold", labelpad=8)
ax.set_ylabel(YLABEL, fontsize=20, fontweight="bold", labelpad=8)

sns.despine()

# ticks and spines
ax.tick_params(axis="x", labelsize=18, width=1.8, length=7)
ax.tick_params(axis="y", labelsize=18, width=1.8, length=7)
for spine in ["left", "bottom"]:
    ax.spines[spine].set_linewidth(1.8)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

fig.tight_layout()
plt.savefig("figure5_lebel.pdf", dpi=300, bbox_inches="tight")


df = pd.read_csv("data_figure5/lpp_fd_analysis.csv")


# ---- SETTINGS ----
X_COL = "mean_fd"
Y_COL = "lanA_mean_avg"
XLABEL = "Mean FD"
YLABEL = "Predictivity"
EXPORT_PATH = "fd_vs_performance.pdf"

SHOW_LINEAR = False  # optional dashed linear reference
SHOW_POWERLAW = True  # show power-law fit + CI
SHOW_PEARSON = False  # also report Pearson r (off by default)

# Bootstrap
N_BOOT = 200
CI = (2.5, 97.5)

# --- Style ---
PRIMARY = "#1F78B4"
SCATTER_ALPHA = 0.85
LINE_WIDTH = 3.2
CI_ALPHA = 0.18

sns.set_style("white")
plt.rcParams["font.family"] = "Arial"


# ===== Helpers =====
def powerlaw(x, a, b, c):
    return a * np.power(x, b) + c


def fit_powerlaw(x, y):
    # Guard against non-finite data
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mxx = np.nanmax(x)
    a0 = (np.nanmax(y) - np.nanmin(y)) / (np.sqrt(mxx + 1e-8) + 1e-8)
    p0 = [a0, -1.0, np.nanmin(y)]
    bounds = ([-np.inf, -5, -np.inf], [np.inf, 5, np.inf])
    popt, _ = optimize.curve_fit(powerlaw, x, y, p0=p0, bounds=bounds, maxfev=20000)
    return popt  # a, b, c


def bootstrap_powerlaw_curve(
    df, x_col, y_col, x_grid, n_boot=1000, ci=(2.5, 97.5), random_state=0
):
    rng = np.random.default_rng(random_state)
    preds = []
    n = len(df)
    for _ in range(n_boot):
        sample = df.sample(n=n, replace=True, random_state=rng.integers(1, 10**9))
        x_b = sample[x_col].to_numpy()
        y_b = sample[y_col].to_numpy()
        if np.any(~np.isfinite(x_b)) or np.any(~np.isfinite(y_b)):
            continue
        try:
            a, b, c = fit_powerlaw(x_b, y_b)
            preds.append(powerlaw(x_grid, a, b, c))
        except Exception:
            continue
    preds = np.array(preds)
    lower = np.nanpercentile(preds, ci[0], axis=0)
    upper = np.nanpercentile(preds, ci[1], axis=0)
    median = np.nanpercentile(preds, 50, axis=0)
    return median, lower, upper


def bootstrap_b_params(df, x_col, y_col, n_boot=1000, ci=(2.5, 97.5), random_state=0):
    rng = np.random.default_rng(random_state)
    bs = []
    n = len(df)
    for _ in range(n_boot):
        sample = df.sample(n=n, replace=True, random_state=rng.integers(1, 10**9))
        x_b = sample[x_col].to_numpy()
        y_b = sample[y_col].to_numpy()
        if np.any(~np.isfinite(x_b)) or np.any(~np.isfinite(y_b)):
            continue
        try:
            _, b, _ = fit_powerlaw(x_b, y_b)
            bs.append(b)
        except Exception:
            continue
    bs = np.array(bs, dtype=float)
    b_med = float(np.nanmedian(bs))
    b_lo, b_hi = [float(v) for v in np.nanpercentile(bs, ci)]
    return b_med, b_lo, b_hi


def r2_powerlaw(x, y, params):
    y_pred = powerlaw(x, *params)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    return 1.0 - ss_res / ss_tot


# ===== Data =====
x = df[X_COL].to_numpy()
y = df[Y_COL].to_numpy()

# Handle edge case: constant vectors break correlations
const_x = np.allclose(np.nanstd(x), 0.0)
const_y = np.allclose(np.nanstd(y), 0.0)

# ===== Plot =====
fig, ax = plt.subplots(figsize=(9.5, 7.2))

# scatter
ax.scatter(x, y, s=95, alpha=SCATTER_ALPHA, edgecolor="none", color=PRIMARY)

# optional linear trend (light)
if SHOW_LINEAR and not const_x and not const_y:
    m, b_lin = np.polyfit(x, y, 1)
    x_lin = np.linspace(x.min(), x.max(), 100)
    ax.plot(
        x_lin,
        m * x_lin + b_lin,
        linestyle="--",
        linewidth=2.0,
        alpha=0.45,
        color="black",
    )

# power-law fit + bootstrap CI + metrics
if SHOW_POWERLAW:
    # fit
    a_hat, b_hat, c_hat = fit_powerlaw(x, y)

    # curve + CI
    x_grid = np.linspace(x.min(), x.max(), 300)
    median, lower, upper = bootstrap_powerlaw_curve(
        df, X_COL, Y_COL, x_grid, n_boot=N_BOOT, ci=CI, random_state=42
    )
    ax.fill_between(x_grid, lower, upper, alpha=CI_ALPHA, color=PRIMARY, linewidth=0)
    ax.plot(x_grid, median, color=PRIMARY, linewidth=LINE_WIDTH)

    # R^2 for the fitted model
    r2 = r2_powerlaw(x, y, (a_hat, b_hat, c_hat))

    # bootstrap b CI
    b_med, b_lo, b_hi = bootstrap_b_params(
        df, X_COL, Y_COL, n_boot=N_BOOT, ci=CI, random_state=123
    )

    # correlations
    rho_text = ""
    if not const_x and not const_y:
        rho, p_rho = stats.spearmanr(x, y)
        rho_text = rf"\n$\rho$ = {rho:0.2f}"
        if SHOW_PEARSON:
            pr, pp = stats.pearsonr(x, y)
            rho_text += rf"  (Pearson $r$ = {pr:0.2f})"

    # annotation text (large, readable)
    metrics_text = r"$R^2$ = " + f"{r2:0.2f}\n" r"$\rho$ = " + f"{rho:0.2f}\n"

    # annotate (top-right inside axes)
    ax.text(
        0.98,
        0.98,
        metrics_text,
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=30,
        fontweight="bold",
    )

# labels
ax.set_xlabel(XLABEL, fontsize=20, fontweight="bold", labelpad=8)
ax.set_ylabel(YLABEL, fontsize=20, fontweight="bold", labelpad=8)

sns.despine()

# ticks and spines
ax.tick_params(axis="x", labelsize=18, width=1.8, length=7)
ax.tick_params(axis="y", labelsize=18, width=1.8, length=7)
for spine in ["left", "bottom"]:
    ax.spines[spine].set_linewidth(1.8)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

fig.tight_layout()
plt.savefig("figure5_lpp.pdf", dpi=300, bbox_inches="tight")
