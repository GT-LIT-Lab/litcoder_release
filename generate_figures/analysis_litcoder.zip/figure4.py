import pandas as pd

df_narratives = pd.read_csv("narratives_folding_final.csv")
df_lpp = pd.read_csv("lpp_temporal_split.csv")

# drop any rows where the mean_correlation is NaN
df_narratives = df_narratives.dropna(subset=["a1_mean"])
df_lpp = df_lpp.dropna(subset=["a1_mean"])
# drop duplicates where model_name, layer_idx, subject are the same
df_narratives = df_narratives.drop_duplicates(
    subset=["model_name", "layer_idx", "subject", "folding_type"]
)
df_lpp = df_lpp.drop_duplicates(
    subset=["model_name", "layer_idx", "subject", "folding_type", "story_idx"]
)

df_narratives_shuffled = df_narratives[
    df_narratives["folding_type"] == "kfold_shuffled"
]
df_narratives_contiguous = df_narratives[df_narratives["folding_type"] == "kfold"]
df_narratives_contiguous_trimmed = df_narratives[
    df_narratives["folding_type"] == "kfold_trimmed"
]

df_lpp_shuffled = df_lpp[df_lpp["folding_type"] == "kfold_shuffled"]
df_lpp_contiguous = df_lpp[df_lpp["folding_type"] == "kfold"]
df_lpp_contiguous_trimmed = df_lpp[df_lpp["folding_type"] == "kfold_trimmed"]

df_lpp_contiguous_trimmed_collapsed = df_lpp_contiguous_trimmed.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
).agg({"mean_correlation": "mean"})
df_lpp_contiguous_collapsed = df_lpp_contiguous.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
).agg({"mean_correlation": "mean"})
df_lpp_shuffled_collapsed = df_lpp_shuffled.groupby(
    ["model_name", "layer_idx", "subject"], as_index=False
).agg({"mean_correlation": "mean"})


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

data = []

# Add Narratives data (13 subjects each)
for score in df_narratives_contiguous_trimmed["mean_correlation"]:
    data.append(("Narratives", "kfold_trimmed", score))
for score in df_narratives_contiguous["mean_correlation"]:
    data.append(("Narratives", "kfold_shuffle=False", score))
for score in df_narratives_shuffled["mean_correlation"]:
    data.append(("Narratives", "kfold_shuffle=True", score))

for score in df_lpp_contiguous_trimmed_collapsed["mean_correlation"]:
    data.append(("Little Prince", "kfold_trimmed", score))
for score in df_lpp_contiguous_collapsed["mean_correlation"]:
    data.append(("Little Prince", "kfold_shuffle=False", score))
for score in df_lpp_shuffled_collapsed["mean_correlation"]:
    data.append(("Little Prince", "kfold_shuffle=True", score))

df = pd.DataFrame(data, columns=["dataset", "shuffle", "score"])

label_map = {
    "kfold_trimmed": "Contiguous + Trimmed",
    "kfold_shuffle=False": "Contiguous",
    "kfold_shuffle=True": "Shuffled",
}
df["condition"] = df["shuffle"].map(label_map)

# Calculate means and SEMs for each group
summary_stats = (
    df.groupby(["dataset", "condition"])["score"].agg(["mean", "sem"]).reset_index()
)

# ---- style ----
sns.set_theme(style="white", context="talk")  # no gridlines
order = ["Shuffled", "Contiguous", "Contiguous + Trimmed"]
palette = sns.color_palette(["#66C2A5", "#FC8D62", "#8DA0CB"])

# ---- plot ----
fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), sharey=True)

for ax, (name, sub_df) in zip(axes, df.groupby("dataset", sort=False)):
    # Get summary stats for this dataset
    sub_stats = summary_stats[summary_stats["dataset"] == name]

    # Create the bar plot
    bars = sns.barplot(
        data=sub_df,
        x="condition",
        y="score",
        order=order,
        palette=palette,
        width=0.65,
        edgecolor="0.25",
        linewidth=0.7,
        ax=ax,
        estimator=np.mean,
        errorbar=None,
    )

    # Add SEM error bars manually
    for i, condition in enumerate(order):
        if condition in sub_stats["condition"].values:
            stats_row = sub_stats[sub_stats["condition"] == condition]
            mean_val = stats_row["mean"].iloc[0]
            sem_val = stats_row["sem"].iloc[0]

            ax.errorbar(
                i,
                mean_val,
                yerr=sem_val,
                fmt="none",
                color="black",
                capsize=3,
                capthick=1,
                linewidth=1,
            )

    ax.set_title(name, pad=10, fontsize=18)
    ax.set_xlabel("")
    ax.set_ylabel("Predictivity" if name == "Narratives" else "")
    ax.set_ylim(0, 0.8)
    ax.tick_params(axis="x", labelsize=14)
    sns.despine(ax=ax)

fig.suptitle("Shuffling Control Scores", y=1.02, fontsize=18)
plt.tight_layout()
plt.savefig(
    "figure4.pdf",
    dpi=300,
    format="pdf",
)
